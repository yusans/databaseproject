/*
 Navicat Premium Data Transfer

 Source Server         : db2022
 Source Server Type    : PostgreSQL
 Source Server Version : 90204
 Source Host           : localhost:15432
 Source Catalog        : dbproject
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90204
 File Encoding         : 65001

 Date: 16/06/2022 18:24:42
*/


-- ----------------------------
-- Table structure for titleakas
-- ----------------------------
DROP TABLE IF EXISTS "public"."titleakas";
CREATE TABLE "public"."titleakas" (
  "titleid" varchar(20) COLLATE "pg_catalog"."default" NOT NULL,
  "ordering" int8 NOT NULL,
  "title" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "region" varchar(50) COLLATE "pg_catalog"."default",
  "language" varchar(30) COLLATE "pg_catalog"."default",
  "types" varchar(50) COLLATE "pg_catalog"."default",
  "attributes" varchar(50) COLLATE "pg_catalog"."default",
  "isOriginalTitle" bit(1)
)
;

-- ----------------------------
-- Indexes structure for table titleakas
-- ----------------------------
CREATE INDEX "titleakas_titleid_idx" ON "public"."titleakas" USING btree (
  "titleid" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Uniques structure for table titleakas
-- ----------------------------
ALTER TABLE "public"."titleakas" ADD CONSTRAINT "titleakas_titleid_key" UNIQUE ("titleid");

-- ----------------------------
-- Primary Key structure for table titleakas
-- ----------------------------
ALTER TABLE "public"."titleakas" ADD CONSTRAINT "titleakas_pkey" PRIMARY KEY ("titleid");
