/*
 Navicat Premium Data Transfer

 Source Server         : db2022
 Source Server Type    : PostgreSQL
 Source Server Version : 90204
 Source Host           : localhost:15432
 Source Catalog        : dbproject
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90204
 File Encoding         : 65001

 Date: 16/06/2022 18:25:00
*/


-- ----------------------------
-- Table structure for titleepisode
-- ----------------------------
DROP TABLE IF EXISTS "public"."titleepisode";
CREATE TABLE "public"."titleepisode" (
  "tconst" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "parenttconst" varchar(50) COLLATE "pg_catalog"."default",
  "seasonnumber" numeric(20),
  "episodenumber" numeric(100)
)
;

-- ----------------------------
-- Indexes structure for table titleepisode
-- ----------------------------
CREATE UNIQUE INDEX "titleepisode_tconst_idx" ON "public"."titleepisode" USING btree (
  "tconst" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table titleepisode
-- ----------------------------
ALTER TABLE "public"."titleepisode" ADD CONSTRAINT "titleepisode_pkey" PRIMARY KEY ("tconst");
