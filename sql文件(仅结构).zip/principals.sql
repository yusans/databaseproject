/*
 Navicat Premium Data Transfer

 Source Server         : db2022
 Source Server Type    : PostgreSQL
 Source Server Version : 90204
 Source Host           : localhost:15432
 Source Catalog        : dbproject
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90204
 File Encoding         : 65001

 Date: 16/06/2022 18:24:27
*/


-- ----------------------------
-- Table structure for principals
-- ----------------------------
DROP TABLE IF EXISTS "public"."principals";
CREATE TABLE "public"."principals" (
  "tconst" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "orderings" numeric(100),
  "nconst" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "category" varchar(50) COLLATE "pg_catalog"."default",
  "job" varchar(50) COLLATE "pg_catalog"."default" DEFAULT '\N'::character varying,
  "characters" varchar(50) COLLATE "pg_catalog"."default" DEFAULT '\N'::character varying
)
;

-- ----------------------------
-- Indexes structure for table principals
-- ----------------------------
CREATE INDEX "principals_nconst_idx" ON "public"."principals" USING btree (
  "nconst" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
CREATE INDEX "principals_tconst_idx" ON "public"."principals" USING btree (
  "tconst" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
