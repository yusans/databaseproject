/*
 Navicat Premium Data Transfer

 Source Server         : db2022
 Source Server Type    : PostgreSQL
 Source Server Version : 90204
 Source Host           : localhost:15432
 Source Catalog        : dbproject
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90204
 File Encoding         : 65001

 Date: 16/06/2022 18:24:54
*/


-- ----------------------------
-- Table structure for titlecrew
-- ----------------------------
DROP TABLE IF EXISTS "public"."titlecrew";
CREATE TABLE "public"."titlecrew" (
  "tconst" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "directors" varchar(50) COLLATE "pg_catalog"."default",
  "writers" varchar(50) COLLATE "pg_catalog"."default",
  "nconst" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Indexes structure for table titlecrew
-- ----------------------------
CREATE UNIQUE INDEX "titlecrew_tconst_idx" ON "public"."titlecrew" USING btree (
  "tconst" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table titlecrew
-- ----------------------------
ALTER TABLE "public"."titlecrew" ADD CONSTRAINT "titlecrew_pkey" PRIMARY KEY ("tconst");
