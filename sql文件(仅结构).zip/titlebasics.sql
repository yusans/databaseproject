/*
 Navicat Premium Data Transfer

 Source Server         : db2022
 Source Server Type    : PostgreSQL
 Source Server Version : 90204
 Source Host           : localhost:15432
 Source Catalog        : dbproject
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90204
 File Encoding         : 65001

 Date: 16/06/2022 18:24:48
*/


-- ----------------------------
-- Table structure for titlebasics
-- ----------------------------
DROP TABLE IF EXISTS "public"."titlebasics";
CREATE TABLE "public"."titlebasics" (
  "tconst" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "titleType" varchar(50) COLLATE "pg_catalog"."default",
  "primaryTitle" varchar(50) COLLATE "pg_catalog"."default",
  "originalTitle" varchar(50) COLLATE "pg_catalog"."default",
  "isAdult" bit(1),
  "startYear" int2,
  "endYear" int2,
  "runtimeMinutes" int2,
  "genres" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Indexes structure for table titlebasics
-- ----------------------------
CREATE UNIQUE INDEX "titlebasics_tconst_idx" ON "public"."titlebasics" USING btree (
  "tconst" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Uniques structure for table titlebasics
-- ----------------------------
ALTER TABLE "public"."titlebasics" ADD CONSTRAINT "titlebasics_tconst_key" UNIQUE ("tconst");

-- ----------------------------
-- Primary Key structure for table titlebasics
-- ----------------------------
ALTER TABLE "public"."titlebasics" ADD CONSTRAINT "titlebasics_pkey" PRIMARY KEY ("tconst");
