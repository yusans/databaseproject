/*
 Navicat Premium Data Transfer

 Source Server         : db2022
 Source Server Type    : PostgreSQL
 Source Server Version : 90204
 Source Host           : localhost:15432
 Source Catalog        : dbproject
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90204
 File Encoding         : 65001

 Date: 16/06/2022 18:24:36
*/


-- ----------------------------
-- Table structure for ratings
-- ----------------------------
DROP TABLE IF EXISTS "public"."ratings";
CREATE TABLE "public"."ratings" (
  "tconst" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "averagerating" numeric(2,1),
  "numvotes" numeric(100)
)
;

-- ----------------------------
-- Indexes structure for table ratings
-- ----------------------------
CREATE INDEX "ratings_tconst_averagerating_numvotes_idx" ON "public"."ratings" USING btree (
  "tconst" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST,
  "averagerating" "pg_catalog"."numeric_ops" ASC NULLS LAST,
  "numvotes" "pg_catalog"."numeric_ops" ASC NULLS LAST
);
CREATE INDEX "ratings_tconst_idx" ON "public"."ratings" USING btree (
  "tconst" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);
