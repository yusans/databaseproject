/*
 Navicat Premium Data Transfer

 Source Server         : db2022
 Source Server Type    : PostgreSQL
 Source Server Version : 90204
 Source Host           : localhost:15432
 Source Catalog        : dbproject
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90204
 File Encoding         : 65001

 Date: 16/06/2022 18:24:19
*/


-- ----------------------------
-- Table structure for namebasics
-- ----------------------------
DROP TABLE IF EXISTS "public"."namebasics";
CREATE TABLE "public"."namebasics" (
  "nconst" varchar(50) COLLATE "pg_catalog"."default" NOT NULL,
  "primaryname" varchar(50) COLLATE "pg_catalog"."default",
  "birthyear" numeric(10),
  "deathyear" varchar(4) COLLATE "pg_catalog"."default" DEFAULT '\N'::character varying,
  "primaryprofession" varchar(50) COLLATE "pg_catalog"."default",
  "knownfortitles" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Indexes structure for table namebasics
-- ----------------------------
CREATE UNIQUE INDEX "constserch" ON "public"."namebasics" USING btree (
  "nconst" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table namebasics
-- ----------------------------
ALTER TABLE "public"."namebasics" ADD CONSTRAINT "namebasics_pkey" PRIMARY KEY ("nconst");
